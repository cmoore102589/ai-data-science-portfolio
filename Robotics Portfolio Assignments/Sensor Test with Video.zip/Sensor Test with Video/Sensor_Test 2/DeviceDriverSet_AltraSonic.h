#ifndef _DeviceDriverSet_AltraSonic_H_
#define _DeviceDriverSet_AltraSonic_H_

#include <Arduino.h>

class DeviceDriverSet_AltraSonic
{
public:
  void DeviceDriverSet_UltraSonic_Init(void);
  int DeviceDriverSet_UltraSonic_Get(void);

private:
  #define TRIG_PIN 10
  #define ECHO_PIN 11
};

#endif

