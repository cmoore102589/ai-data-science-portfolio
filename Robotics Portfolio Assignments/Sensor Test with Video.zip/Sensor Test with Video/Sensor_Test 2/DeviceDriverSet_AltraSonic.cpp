#include "DeviceDriverSet_AltraSonic.h"

void DeviceDriverSet_AltraSonic::DeviceDriverSet_UltraSonic_Init(void)
{
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
}

int DeviceDriverSet_AltraSonic::DeviceDriverSet_UltraSonic_Get(void)
{
  long duration;
  int distance;

  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  duration = pulseIn(ECHO_PIN, HIGH);
  distance = (duration / 2) / 29.1; // Convert to centimeters

  return distance;
}
