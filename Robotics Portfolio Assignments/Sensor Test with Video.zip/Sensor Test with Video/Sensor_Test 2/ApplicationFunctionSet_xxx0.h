#ifndef _APPLICATIONFUNCTIONSET_XXX0_H_
#define _APPLICATIONFUNCTIONSET_XXX0_H_

#include "DeviceDriverSet_xxx0.h"

extern DeviceDriverSet_Motor AppMotor;

enum SmartRobotCarMotionControl
{
  Forward,
  Backward,
  Left,
  Right,
  stop_it
};

struct Application_xxx
{
  SmartRobotCarMotionControl Motion_Control;
};

extern Application_xxx Application_SmartRobotCarxxx0;

void ApplicationFunctionSet_SmartRobotCarMotionControl(SmartRobotCarMotionControl direction, uint8_t speed);

#endif
