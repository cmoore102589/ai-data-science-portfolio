#include "ApplicationFunctionSet_xxx0.h"

void ApplicationFunctionSet_SmartRobotCarMotionControl(SmartRobotCarMotionControl direction, uint8_t speed)
{
  switch (direction)
  {
  case Forward:
    AppMotor.DeviceDriverSet_Motor_control(direction_just, speed, direction_just, speed, control_enable);
    break;
  case Backward:
    AppMotor.DeviceDriverSet_Motor_control(direction_back, speed, direction_back, speed, control_enable);
    break;
  case Left:
    AppMotor.DeviceDriverSet_Motor_control(direction_just, speed, direction_back, speed, control_enable);
    break;
  case Right:
    AppMotor.DeviceDriverSet_Motor_control(direction_back, speed, direction_just, speed, control_enable);
    break;
  case stop_it:
    AppMotor.DeviceDriverSet_Motor_control(direction_void, 0, direction_void, 0, control_enable);
    break;
  default:
    break;
  }
}
